# Report Creator — Android PWA

This folder is a ready-to-host Progressive Web App built from the Report Creator HTML.

## Important
A PWA must be served from HTTPS (or localhost during testing). Opening `index.html` directly with `file://` will not enable installation/service-worker features.

## Test on a computer
From this folder run:

    python -m http.server 8080

Then open http://localhost:8080 in Chrome.

## Install on Android
1. Upload this folder to any HTTPS web host.
2. Open the HTTPS address in Chrome on Android.
3. Use Chrome menu → Add to Home screen / Install app.
4. Launch Report Creator from the Android home screen.

## Data
Existing reports/settings continue to use browser localStorage. Telegram sending still requires internet access and valid Telegram configuration.

## Security
Do not publish a real Telegram bot token in client-side HTML. Move the Telegram API call to a backend before public deployment and rotate any token that has previously been exposed.
